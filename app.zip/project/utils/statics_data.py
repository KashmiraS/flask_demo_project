not_in_result = ['uid', 'pid']
must_in_result = ['project_releasing', 'project_starting_date']
date_in_result = [ 'project_releasing', 'project_starting_date']
dates=['start_date','end_date']
